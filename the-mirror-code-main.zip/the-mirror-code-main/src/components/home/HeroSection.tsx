import { Link } from "react-router-dom";
import { CalendarDays, MapPin, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import CountdownTimer from "./CountdownTimer";
import heroBg from "@/assets/hero-bg.jpg";

const HeroSection = () => {
  return (
    <section className="relative min-h-[90vh] flex items-center overflow-hidden">
      {/* Background image */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url(${heroBg})` }}
      />
      
      {/* Overlay */}
      <div className="absolute inset-0 bg-gradient-to-r from-primary-dark/95 via-primary/90 to-primary/80" />

      {/* Content */}
      <div className="relative container mx-auto px-4 py-20">
        <div className="max-w-4xl mx-auto text-center">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent/20 border border-accent/30 text-accent mb-6 animate-fade-in">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-accent opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-accent"></span>
            </span>
            <span className="text-sm font-medium">Registration Open</span>
          </div>

          {/* Title */}
          <h1 className="font-display text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold text-primary-foreground mb-4 animate-fade-in-up">
            SciFusion <span className="text-accent">1.0</span>
          </h1>
          
          {/* Tagline */}
          <p className="text-xl sm:text-2xl md:text-3xl text-primary-foreground/90 font-display mb-8 animate-fade-in-up animation-delay-100">
            Two Days National Conference on<br />
            <span className="text-accent">Interdisciplinary Scientific Research</span>
          </p>

          {/* Info badges */}
          <div className="flex flex-wrap justify-center gap-4 mb-8 animate-fade-in-up animation-delay-200">
            <InfoBadge icon={<CalendarDays className="w-5 h-5" />} text="13th & 14th March 2026" />
            <InfoBadge icon={<MapPin className="w-5 h-5" />} text="Navi Mumbai, India" />
            <InfoBadge icon={<Users className="w-5 h-5" />} text="300+ Expected Delegates" />
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-wrap justify-center gap-4 mb-12 animate-fade-in-up animation-delay-300">
            <Button variant="hero" size="xl" asChild>
              <Link to="/registration">Register Now</Link>
            </Button>
            <Button variant="heroOutline" size="xl" asChild>
              <Link to="/submission">Submit Paper</Link>
            </Button>
          </div>

          {/* Countdown */}
          <div className="animate-fade-in-up animation-delay-400">
            <p className="text-primary-foreground/70 text-sm mb-3 uppercase tracking-wider">
              Conference Starts In
            </p>
            <CountdownTimer targetDate="2026-03-13T09:00:00" />
          </div>
        </div>
      </div>

      {/* Decorative elements */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-background to-transparent" />
    </section>
  );
};

const InfoBadge = ({ icon, text }: { icon: React.ReactNode; text: string }) => (
  <div className="flex items-center gap-2 px-4 py-2 rounded-lg bg-primary-foreground/10 text-primary-foreground border border-primary-foreground/20">
    {icon}
    <span className="text-sm font-medium">{text}</span>
  </div>
);

export default HeroSection;
