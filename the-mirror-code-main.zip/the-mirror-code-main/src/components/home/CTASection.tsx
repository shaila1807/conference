import { Link } from "react-router-dom";
import { ArrowRight, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";

const CTASection = () => {
  return (
    <section className="py-20 bg-card relative overflow-hidden">
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: `radial-gradient(circle at 2px 2px, currentColor 1px, transparent 0)`,
          backgroundSize: '40px 40px',
        }} />
      </div>

      <div className="container mx-auto px-4 relative">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold text-foreground mb-4">
            Ready to Present Your Research?
          </h2>
          <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
            Join leading researchers, scientists, and academics from across the nation. 
            Register now to secure your spot at SciFusion 1.0.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-8">
            <Button variant="hero" size="xl" asChild>
              <Link to="/registration" className="inline-flex items-center gap-2">
                Register Now
                <ArrowRight className="w-5 h-5" />
              </Link>
            </Button>
            <Button variant="goldOutline" size="xl" asChild>
              <Link to="/contact" className="inline-flex items-center gap-2">
                <Phone className="w-5 h-5" />
                Contact Us
              </Link>
            </Button>
          </div>

          {/* Contact info */}
          <p className="text-sm text-muted-foreground">
            Questions? Contact Asst. Prof. Madhavi Joshi at{" "}
            <a href="tel:7718960509" className="text-accent hover:underline font-medium">
              7718960509
            </a>
          </p>
        </div>
      </div>
    </section>
  );
};

export default CTASection;
