import { Link } from "react-router-dom";
import { FlaskConical, Calculator, Cpu, Leaf, Bug, UtensilsCrossed, Atom, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

const themes = [
  { icon: <FlaskConical className="w-6 h-6" />, name: "Chemistry", color: "from-orange-500 to-red-500" },
  { icon: <Calculator className="w-6 h-6" />, name: "Mathematics", color: "from-blue-500 to-indigo-500" },
  { icon: <Cpu className="w-6 h-6" />, name: "Information Technology", color: "from-cyan-500 to-blue-500" },
  { icon: <Atom className="w-6 h-6" />, name: "Physics", color: "from-purple-500 to-pink-500" },
  { icon: <Leaf className="w-6 h-6" />, name: "Botany", color: "from-green-500 to-emerald-500" },
  { icon: <Bug className="w-6 h-6" />, name: "Zoology", color: "from-amber-500 to-orange-500" },
  { icon: <UtensilsCrossed className="w-6 h-6" />, name: "Hospitality Studies", color: "from-rose-500 to-red-500" },
];

const ThemesPreviewSection = () => {
  return (
    <section className="py-20 gradient-hero text-primary-foreground">
      <div className="container mx-auto px-4">
        {/* Section header */}
        <div className="text-center mb-12">
          <span className="text-accent font-semibold text-sm uppercase tracking-wider">
            Call For Papers
          </span>
          <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold mt-2 mb-4">
            Research Themes
          </h2>
          <p className="text-primary-foreground/80 max-w-2xl mx-auto">
            Submit your research in any of these interdisciplinary scientific domains.
          </p>
        </div>

        {/* Themes grid */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {themes.map((theme, index) => (
            <div
              key={index}
              className="group flex items-center gap-3 px-6 py-4 rounded-lg bg-primary-foreground/10 border border-primary-foreground/20 hover:bg-primary-foreground/20 hover:border-accent/50 transition-all duration-300 cursor-pointer"
            >
              <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${theme.color} flex items-center justify-center text-white group-hover:scale-110 transition-transform duration-300`}>
                {theme.icon}
              </div>
              <span className="font-medium">{theme.name}</span>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="text-center">
          <Button variant="hero" size="lg" asChild>
            <Link to="/themes" className="inline-flex items-center gap-2">
              View All Themes
              <ArrowRight className="w-4 h-4" />
            </Link>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default ThemesPreviewSection;
