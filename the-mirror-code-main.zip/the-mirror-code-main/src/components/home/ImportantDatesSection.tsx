import { CalendarClock, FileCheck, Bell, Send } from "lucide-react";

const dates = [
  {
    icon: <CalendarClock className="w-6 h-6" />,
    date: "16th Feb 2026",
    title: "Registration Deadline",
    description: "Last date for conference registration",
  },
  {
    icon: <FileCheck className="w-6 h-6" />,
    date: "16th Feb 2026",
    title: "Abstract Submission",
    description: "Submit your research abstract",
  },
  {
    icon: <Bell className="w-6 h-6" />,
    date: "21st Feb 2026",
    title: "Acceptance Notification",
    description: "Notification of paper acceptance",
  },
  {
    icon: <Send className="w-6 h-6" />,
    date: "22nd Mar 2026",
    title: "Full Paper Submission",
    description: "Submit complete research paper",
  },
];

const ImportantDatesSection = () => {
  return (
    <section className="py-20 bg-card">
      <div className="container mx-auto px-4">
        {/* Section header */}
        <div className="text-center mb-12">
          <span className="text-accent font-semibold text-sm uppercase tracking-wider">
            Mark Your Calendar
          </span>
          <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold text-foreground mt-2 mb-4">
            Important Dates
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Don't miss these crucial deadlines for conference participation and paper submission.
          </p>
        </div>

        {/* Timeline */}
        <div className="max-w-4xl mx-auto">
          <div className="relative">
            {/* Timeline line */}
            <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-gradient-to-b from-accent via-secondary to-primary hidden md:block" />

            {/* Date items */}
            <div className="space-y-8">
              {dates.map((item, index) => (
                <div
                  key={index}
                  className="relative flex items-start gap-6 group"
                >
                  {/* Icon */}
                  <div className="relative z-10 w-16 h-16 rounded-full gradient-hero flex items-center justify-center text-primary-foreground shrink-0 shadow-card group-hover:scale-110 transition-transform duration-300">
                    {item.icon}
                  </div>

                  {/* Content */}
                  <div className="flex-1 bg-background border border-border rounded-lg p-6 shadow-soft group-hover:shadow-card group-hover:border-accent/30 transition-all duration-300">
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mb-2">
                      <h3 className="font-display text-xl font-semibold text-foreground">
                        {item.title}
                      </h3>
                      <span className="text-accent font-bold font-display">
                        {item.date}
                      </span>
                    </div>
                    <p className="text-muted-foreground">
                      {item.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ImportantDatesSection;
