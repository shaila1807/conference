import { Calendar, FileText, Award, Users, Microscope, BookOpen } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const highlights = [
  {
    icon: <Microscope className="w-8 h-8" />,
    title: "7+ Research Themes",
    description: "Chemistry, Mathematics, IT, Physics, Botany, Zoology, and Hospitality Studies",
  },
  {
    icon: <Users className="w-8 h-8" />,
    title: "Distinguished Speakers",
    description: "Keynote addresses from leading scientists and industry experts",
  },
  {
    icon: <FileText className="w-8 h-8" />,
    title: "Paper Presentation",
    description: "Present your research to a national audience of scholars",
  },
  {
    icon: <Award className="w-8 h-8" />,
    title: "Scopus Publication",
    description: "Selected papers published in Scopus-indexed journal",
  },
  {
    icon: <BookOpen className="w-8 h-8" />,
    title: "Lab to Land Session",
    description: "Interactive session connecting scientists with local farmers",
  },
  {
    icon: <Calendar className="w-8 h-8" />,
    title: "2 Days of Networking",
    description: "Connect with researchers, industry professionals, and academics",
  },
];

const HighlightsSection = () => {
  return (
    <section className="py-20 gradient-section">
      <div className="container mx-auto px-4">
        {/* Section header */}
        <div className="text-center mb-12">
          <span className="text-accent font-semibold text-sm uppercase tracking-wider">
            Why Attend
          </span>
          <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold text-foreground mt-2 mb-4">
            Conference Highlights
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Join us for a transformative academic experience featuring cutting-edge research, 
            expert insights, and valuable networking opportunities.
          </p>
        </div>

        {/* Highlights grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {highlights.map((highlight, index) => (
            <Card
              key={index}
              className="group bg-card border-border hover:border-accent/50 transition-all duration-300 hover:shadow-card overflow-hidden"
            >
              <CardContent className="p-6">
                <div className="w-14 h-14 rounded-lg gradient-hero flex items-center justify-center text-primary-foreground mb-4 group-hover:scale-110 transition-transform duration-300">
                  {highlight.icon}
                </div>
                <h3 className="font-display text-xl font-semibold text-foreground mb-2">
                  {highlight.title}
                </h3>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  {highlight.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default HighlightsSection;
