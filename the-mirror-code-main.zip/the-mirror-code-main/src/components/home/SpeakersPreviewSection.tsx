import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

const speakers = [
  {
    name: "Prof. (Dr.) B. M. Bhanage",
    title: "Vice Chancellor",
    institution: "MS University, Baroda",
    expertise: "Catalysis & Green Synthesis",
  },
  {
    name: "Dr. Achyut Godbole",
    title: "Scientist & Author",
    institution: "IIT Mumbai Alumni",
    expertise: "Technology & Entrepreneurship",
  },
  {
    name: "Prof. A.V. Mahajan",
    title: "Professor of Physics",
    institution: "IIT Bombay",
    expertise: "Quantum Magnetism",
  },
  {
    name: "Dr. Anupam Dhoundiyal",
    title: "Dean of Hospitality Studies",
    institution: "TS Rahaman Nhava",
    expertise: "Hospitality Management",
  },
];

const SpeakersPreviewSection = () => {
  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-4">
        {/* Section header */}
        <div className="text-center mb-12">
          <span className="text-accent font-semibold text-sm uppercase tracking-wider">
            Learn From The Best
          </span>
          <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold text-foreground mt-2 mb-4">
            Keynote Speakers
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Distinguished scientists, academics, and industry leaders sharing their expertise.
          </p>
        </div>

        {/* Speakers grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {speakers.map((speaker, index) => (
            <Card
              key={index}
              className="group bg-card border-border hover:border-accent/50 transition-all duration-300 hover:shadow-card overflow-hidden"
            >
              <CardContent className="p-6 text-center">
                {/* Avatar placeholder */}
                <div className="w-24 h-24 rounded-full gradient-hero mx-auto mb-4 flex items-center justify-center">
                  <span className="font-display text-2xl font-bold text-primary-foreground">
                    {speaker.name.split(' ').map(n => n[0]).join('').slice(0, 2)}
                  </span>
                </div>
                
                <h3 className="font-display text-lg font-semibold text-foreground mb-1">
                  {speaker.name}
                </h3>
                <p className="text-accent text-sm font-medium mb-1">
                  {speaker.title}
                </p>
                <p className="text-muted-foreground text-sm mb-2">
                  {speaker.institution}
                </p>
                <p className="text-xs text-muted-foreground/70 italic">
                  {speaker.expertise}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* CTA */}
        <div className="text-center">
          <Button variant="default" size="lg" asChild>
            <Link to="/speakers" className="inline-flex items-center gap-2">
              View All Speakers
              <ArrowRight className="w-4 h-4" />
            </Link>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default SpeakersPreviewSection;
