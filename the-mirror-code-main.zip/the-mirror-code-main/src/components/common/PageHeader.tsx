import { ReactNode } from "react";

interface PageHeaderProps {
  badge?: string;
  title: string;
  subtitle?: string;
}

const PageHeader = ({ badge, title, subtitle }: PageHeaderProps) => {
  return (
    <section className="gradient-hero text-primary-foreground py-20">
      <div className="container mx-auto px-4 text-center">
        {badge && (
          <span className="inline-block text-accent font-semibold text-sm uppercase tracking-wider mb-3">
            {badge}
          </span>
        )}
        <h1 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">
          {title}
        </h1>
        {subtitle && (
          <p className="text-primary-foreground/80 max-w-2xl mx-auto text-lg">
            {subtitle}
          </p>
        )}
      </div>
    </section>
  );
};

export default PageHeader;
