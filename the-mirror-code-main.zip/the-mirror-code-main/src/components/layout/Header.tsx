import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { Menu, X, ChevronDown, Mail, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
} from "@/components/ui/navigation-menu";
import { cn } from "@/lib/utils";
import kleLogo from "@/assets/kle-logo.jpg";
import collegeLogo from "@/assets/college-logo.png";

const Header = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path;

  const aboutUsLinks = [
    { title: "About Society", href: "/about-society", description: "Learn about KLE Society's legacy" },
    { title: "About College", href: "/about-college", description: "Discover our institution" },
    { title: "Conference Patron", href: "/patron", description: "Meet our distinguished patrons" },
  ];

  const conferenceLinks = [
    { title: "About Conference", href: "/about-conference", description: "Conference objectives and goals" },
    { title: "Themes", href: "/themes", description: "Research themes and topics" },
    { title: "Submission Guidelines", href: "/submission", description: "Paper submission process" },
    { title: "Registration", href: "/registration", description: "Registration details and fees" },
  ];

  const speakersLinks = [
    { title: "Keynote Speakers", href: "/speakers", description: "Distinguished keynote speakers" },
    { title: "National Advisory Board", href: "/advisory-board", description: "Our advisory committee" },
  ];

  return (
    <header className="sticky top-0 z-50 w-full">
      {/* College Info Bar */}
      <div className="bg-primary text-primary-foreground border-b border-primary-light/20">
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-center justify-center gap-4 md:gap-8">
            {/* Left Logo - KLE Society */}
            <img 
              src={kleLogo} 
              alt="KLE Society Logo" 
              className="h-16 md:h-20 w-auto object-contain"
            />
            
            {/* College Name - Center */}
            <div className="flex flex-col items-center text-center">
              <h1 className="font-display text-sm md:text-lg lg:text-xl font-bold uppercase tracking-wide">
                K.L.E. SOCIETY'S SCIENCE AND COMMERCE COLLEGE
              </h1>
              <p className="text-xs text-primary-foreground/80">
                Plot No. 29, Sector-01, Kalamboli, Navi Mumbai – 410218 NAAC Accredited B+ Grade(First Cycle)
              </p>
              <p className="text-xs text-primary-foreground/80">
                (Affiliated to University of Mumbai)
              </p>
            </div>
            
            {/* Right Logo - College */}
            <img 
              src={collegeLogo} 
              alt="Science and Commerce College Logo" 
              className="h-16 md:h-20 w-auto object-contain"
            />
          </div>
        </div>
      </div>

      {/* Contact & Date Bar */}
      <div className="gradient-hero text-primary-foreground">
        <div className="container mx-auto px-4 py-2 flex justify-between items-center text-sm">
          <div className="flex items-center gap-6">
            <a href="tel:022-27423300" className="flex items-center gap-2 hover:text-accent transition-colors">
              <Phone className="w-4 h-4" />
              <span className="hidden sm:inline">022-27423300</span>
            </a>
            <a href="mailto:scienceconference@klessccmumbai.edu.in" className="flex items-center gap-2 hover:text-accent transition-colors">
              <Mail className="w-4 h-4" />
              <span className="hidden md:inline">scienceconference@klessccmumbai.edu.in</span>
            </a>
          </div>
          <div className="text-xs sm:text-sm">
            <span className="font-semibold">13th & 14th March 2026</span>
          </div>
        </div>
      </div>

      {/* Main header */}
      <div className="bg-card/95 backdrop-blur-md border-b border-border shadow-soft">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-20">
            {/* Logo */}
            <Link to="/" className="flex items-center gap-3 group">
              <div className="flex flex-col">
                <span className="font-display text-2xl font-bold text-primary group-hover:text-primary-light transition-colors">
                  SciFusion <span className="text-accent">1.0</span>
                </span>
                <span className="text-xs text-muted-foreground hidden sm:block">
                  National Conference 2026
                </span>
              </div>
            </Link>

            {/* Desktop Navigation */}
            <NavigationMenu className="hidden lg:flex">
              <NavigationMenuList className="gap-1">
                <NavigationMenuItem>
                  <Link to="/">
                    <NavigationMenuLink
                      className={cn(
                        "group inline-flex h-10 w-max items-center justify-center rounded-md bg-background px-4 py-2 text-sm font-medium transition-colors hover:bg-muted hover:text-foreground focus:bg-muted focus:text-foreground focus:outline-none disabled:pointer-events-none disabled:opacity-50",
                        isActive("/") && "bg-muted text-primary"
                      )}
                    >
                      Home
                    </NavigationMenuLink>
                  </Link>
                </NavigationMenuItem>

                <NavigationMenuItem>
                  <NavigationMenuTrigger className="bg-transparent">About Us</NavigationMenuTrigger>
                  <NavigationMenuContent>
                    <ul className="grid w-[400px] gap-3 p-4 md:w-[500px] md:grid-cols-2">
                      {aboutUsLinks.map((link) => (
                        <li key={link.href}>
                          <NavigationMenuLink asChild>
                            <Link
                              to={link.href}
                              className="block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-muted hover:text-foreground focus:bg-muted focus:text-foreground"
                            >
                              <div className="text-sm font-medium leading-none">{link.title}</div>
                              <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
                                {link.description}
                              </p>
                            </Link>
                          </NavigationMenuLink>
                        </li>
                      ))}
                    </ul>
                  </NavigationMenuContent>
                </NavigationMenuItem>

                <NavigationMenuItem>
                  <NavigationMenuTrigger className="bg-transparent">Conference</NavigationMenuTrigger>
                  <NavigationMenuContent>
                    <ul className="grid w-[400px] gap-3 p-4 md:w-[500px] md:grid-cols-2">
                      {conferenceLinks.map((link) => (
                        <li key={link.href}>
                          <NavigationMenuLink asChild>
                            <Link
                              to={link.href}
                              className="block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-muted hover:text-foreground focus:bg-muted focus:text-foreground"
                            >
                              <div className="text-sm font-medium leading-none">{link.title}</div>
                              <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
                                {link.description}
                              </p>
                            </Link>
                          </NavigationMenuLink>
                        </li>
                      ))}
                    </ul>
                  </NavigationMenuContent>
                </NavigationMenuItem>

                <NavigationMenuItem>
                  <NavigationMenuTrigger className="bg-transparent">Speakers</NavigationMenuTrigger>
                  <NavigationMenuContent>
                    <ul className="grid w-[350px] gap-3 p-4">
                      {speakersLinks.map((link) => (
                        <li key={link.href}>
                          <NavigationMenuLink asChild>
                            <Link
                              to={link.href}
                              className="block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-muted hover:text-foreground focus:bg-muted focus:text-foreground"
                            >
                              <div className="text-sm font-medium leading-none">{link.title}</div>
                              <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
                                {link.description}
                              </p>
                            </Link>
                          </NavigationMenuLink>
                        </li>
                      ))}
                    </ul>
                  </NavigationMenuContent>
                </NavigationMenuItem>

                <NavigationMenuItem>
                  <Link to="/schedule">
                    <NavigationMenuLink
                      className={cn(
                        "group inline-flex h-10 w-max items-center justify-center rounded-md bg-background px-4 py-2 text-sm font-medium transition-colors hover:bg-muted hover:text-foreground focus:bg-muted focus:text-foreground focus:outline-none",
                        isActive("/schedule") && "bg-muted text-primary"
                      )}
                    >
                      Schedule
                    </NavigationMenuLink>
                  </Link>
                </NavigationMenuItem>

                <NavigationMenuItem>
                  <Link to="/contact">
                    <NavigationMenuLink
                      className={cn(
                        "group inline-flex h-10 w-max items-center justify-center rounded-md bg-background px-4 py-2 text-sm font-medium transition-colors hover:bg-muted hover:text-foreground focus:bg-muted focus:text-foreground focus:outline-none",
                        isActive("/contact") && "bg-muted text-primary"
                      )}
                    >
                      Contact
                    </NavigationMenuLink>
                  </Link>
                </NavigationMenuItem>
              </NavigationMenuList>
            </NavigationMenu>

            {/* CTA Button */}
            <div className="hidden lg:block">
              <Button variant="hero" size="lg" asChild>
                <Link to="/registration">Register Now</Link>
              </Button>
            </div>

            {/* Mobile menu button */}
            <button
              className="lg:hidden p-2 rounded-md hover:bg-muted transition-colors"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <div className="lg:hidden border-t border-border bg-card animate-fade-in">
            <nav className="container mx-auto px-4 py-4 space-y-2">
              <MobileNavLink to="/" onClick={() => setMobileMenuOpen(false)}>Home</MobileNavLink>
              
              <MobileNavGroup title="About Us">
                {aboutUsLinks.map((link) => (
                  <MobileNavLink key={link.href} to={link.href} onClick={() => setMobileMenuOpen(false)} isChild>
                    {link.title}
                  </MobileNavLink>
                ))}
              </MobileNavGroup>

              <MobileNavGroup title="Conference">
                {conferenceLinks.map((link) => (
                  <MobileNavLink key={link.href} to={link.href} onClick={() => setMobileMenuOpen(false)} isChild>
                    {link.title}
                  </MobileNavLink>
                ))}
              </MobileNavGroup>

              <MobileNavGroup title="Speakers">
                {speakersLinks.map((link) => (
                  <MobileNavLink key={link.href} to={link.href} onClick={() => setMobileMenuOpen(false)} isChild>
                    {link.title}
                  </MobileNavLink>
                ))}
              </MobileNavGroup>

              <MobileNavLink to="/schedule" onClick={() => setMobileMenuOpen(false)}>Schedule</MobileNavLink>
              <MobileNavLink to="/contact" onClick={() => setMobileMenuOpen(false)}>Contact</MobileNavLink>

              <div className="pt-4">
                <Button variant="hero" size="lg" className="w-full" asChild>
                  <Link to="/registration" onClick={() => setMobileMenuOpen(false)}>Register Now</Link>
                </Button>
              </div>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

const MobileNavLink = ({
  to,
  children,
  onClick,
  isChild = false,
}: {
  to: string;
  children: React.ReactNode;
  onClick?: () => void;
  isChild?: boolean;
}) => (
  <Link
    to={to}
    onClick={onClick}
    className={cn(
      "block py-2 px-3 rounded-md transition-colors hover:bg-muted",
      isChild && "pl-6 text-sm text-muted-foreground hover:text-foreground"
    )}
  >
    {children}
  </Link>
);

const MobileNavGroup = ({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) => {
  const [open, setOpen] = useState(false);

  return (
    <div>
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center justify-between py-2 px-3 rounded-md transition-colors hover:bg-muted"
      >
        <span>{title}</span>
        <ChevronDown className={cn("w-4 h-4 transition-transform", open && "rotate-180")} />
      </button>
      {open && <div className="mt-1 space-y-1">{children}</div>}
    </div>
  );
};

export default Header;
