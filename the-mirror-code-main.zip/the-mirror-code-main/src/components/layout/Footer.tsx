import { Link } from "react-router-dom";
import { Mail, Phone, MapPin, ExternalLink } from "lucide-react";

const Footer = () => {
  return (
    <footer className="gradient-hero text-primary-foreground">
      {/* Main footer content */}
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* About */}
          <div className="space-y-4">
            <h3 className="font-display text-2xl font-bold">
              SciFusion <span className="text-accent">1.0</span>
            </h3>
            <p className="text-primary-foreground/80 text-sm leading-relaxed">
              Two Days National Conference on Interdisciplinary Scientific Research
            </p>
            <p className="text-primary-foreground/80 text-sm font-semibold">
              13th & 14th March 2026
            </p>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h4 className="font-display text-lg font-semibold text-accent">Quick Links</h4>
            <nav className="flex flex-col space-y-2">
              <FooterLink to="/about-conference">About Conference</FooterLink>
              <FooterLink to="/themes">Research Themes</FooterLink>
              <FooterLink to="/submission">Submission Guidelines</FooterLink>
              <FooterLink to="/registration">Registration</FooterLink>
              <FooterLink to="/speakers">Keynote Speakers</FooterLink>
            </nav>
          </div>

          {/* Contact Info */}
          <div className="space-y-4">
            <h4 className="font-display text-lg font-semibold text-accent">Contact</h4>
            <div className="space-y-3 text-sm">
              <a
                href="tel:022-27423300"
                className="flex items-center gap-3 text-primary-foreground/80 hover:text-accent transition-colors"
              >
                <Phone className="w-4 h-4 shrink-0" />
                <span>022-27423300</span>
              </a>
              <a
                href="mailto:scienceconference@klessccmumbai.edu.in"
                className="flex items-start gap-3 text-primary-foreground/80 hover:text-accent transition-colors"
              >
                <Mail className="w-4 h-4 shrink-0 mt-0.5" />
                <span className="break-all">scienceconference@klessccmumbai.edu.in</span>
              </a>
              <div className="flex items-start gap-3 text-primary-foreground/80">
                <MapPin className="w-4 h-4 shrink-0 mt-0.5" />
                <span>
                  K.L.E. Society's Science and Commerce College<br />
                  Plot No. 29, Sector-01, Kalamboli<br />
                  Navi Mumbai – 410218
                </span>
              </div>
            </div>
          </div>

          {/* Organized By */}
          <div className="space-y-4">
            <h4 className="font-display text-lg font-semibold text-accent">Organized By</h4>
            <div className="space-y-2 text-sm text-primary-foreground/80">
              <p className="font-semibold text-primary-foreground">K.L.E. Society's</p>
              <p>Science and Commerce College</p>
              <p>Kalamboli, Navi Mumbai</p>
              <p className="text-accent">NAAC Accredited B+ Grade</p>
              <p>(Affiliated to University of Mumbai)</p>
              <a
                href="https://klessccmumbai.edu.in"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 text-accent hover:underline mt-2"
              >
                Visit College Website
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Sponsor bar */}
      <div className="border-t border-primary-foreground/10 py-6">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-sm text-primary-foreground/60">Our Sponsors</p>
            <div className="flex items-center gap-6">
              <div className="text-center">
                <p className="font-semibold text-primary-foreground">In House Enterprises</p>
                <p className="text-xs text-primary-foreground/60">Nerul, Navi Mumbai</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-primary-foreground/10 py-4">
        <div className="container mx-auto px-4 text-center text-sm text-primary-foreground/60">
          <p>© 2026 SciFusion 1.0. All rights reserved. | K.L.E. Society's Science and Commerce College</p>
        </div>
      </div>
    </footer>
  );
};

const FooterLink = ({ to, children }: { to: string; children: React.ReactNode }) => (
  <Link
    to={to}
    className="text-sm text-primary-foreground/80 hover:text-accent transition-colors"
  >
    {children}
  </Link>
);

export default Footer;
