import PageLayout from "@/components/layout/PageLayout";
import PageHeader from "@/components/common/PageHeader";
import { Card, CardContent } from "@/components/ui/card";

const AboutSociety = () => {
  return (
    <PageLayout>
      <PageHeader
        badge="About Us"
        title="KLE Society"
        subtitle="Karnataka Lingayat Education Society - A Legacy of Excellence"
      />

      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <Card className="border-border shadow-card">
              <CardContent className="p-8 md:p-12">
                <h2 className="font-display text-2xl font-bold text-foreground mb-6">
                  Our Heritage
                </h2>
                <div className="prose prose-lg max-w-none text-muted-foreground space-y-6">
                  <p className="leading-relaxed">
                    Karnataka Lingayat Education (KLE) Society emphasizes the sound mind and 
                    healthy body for spiritual enlightenment and social transformation. The 
                    foundation of KLE Society was laid on <span className="text-accent font-semibold">November 13, 1916</span>, 
                    by seven young teachers remembered as <span className="font-display font-semibold text-foreground">"Saptarishis"</span> who 
                    had a vision to spread the light of education amongst all sections of society.
                  </p>
                  
                  <p className="leading-relaxed">
                    This initiation further ushered in a new dawn in the realm of education. 
                    The society is growing thereafter from strength to strength.
                  </p>

                  <div className="bg-muted rounded-lg p-6 my-8">
                    <h3 className="font-display text-xl font-semibold text-foreground mb-4">
                      Our Reach Today
                    </h3>
                    <p className="leading-relaxed">
                      At present there are <span className="text-accent font-bold">316 institutions</span> in 
                      the diverse faculties ranging from arts, science, commerce, medicine, engineering, 
                      dental, pharmacy, architecture, law, nursing, Ayurveda, management, IT, and computer 
                      science, catering to services from kindergarten to post-graduation and professional research.
                    </p>
                  </div>

                  <p className="leading-relaxed">
                    KLE is a vibrant society led by our charismatic chairman, 
                    <span className="font-display font-semibold text-foreground"> Dr. Prabhakar Kore</span>, 
                    who has completely transformed lives through his relentless effort, commitment, 
                    and contributions through health care and education.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </PageLayout>
  );
};

export default AboutSociety;
