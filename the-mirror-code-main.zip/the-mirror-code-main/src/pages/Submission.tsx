import { Link } from "react-router-dom";
import PageLayout from "@/components/layout/PageLayout";
import PageHeader from "@/components/common/PageHeader";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CheckCircle, FileText, CreditCard, Send, ArrowRight, Calendar } from "lucide-react";

const steps = [
  { icon: <FileText className="w-6 h-6" />, title: "Register", description: "Complete the registration form" },
  { icon: <Send className="w-6 h-6" />, title: "Abstract Submission", description: "Submit your research abstract" },
  { icon: <CreditCard className="w-6 h-6" />, title: "Payment", description: "Pay the registration fee" },
  { icon: <FileText className="w-6 h-6" />, title: "Full Paper", description: "Submit complete paper" },
  { icon: <CheckCircle className="w-6 h-6" />, title: "Review Process", description: "Paper undergoes peer review" },
  { icon: <CheckCircle className="w-6 h-6" />, title: "Publish", description: "Accepted papers are published" },
];

const dates = [
  { event: "Last date for Registration", date: "16th Feb 2026" },
  { event: "Abstract submission date", date: "16th Feb 2026" },
  { event: "Notification of acceptance", date: "21st Feb 2026" },
  { event: "Submission of Full length Paper", date: "22nd Mar 2026" },
];

const Submission = () => {
  return (
    <PageLayout>
      <PageHeader
        badge="Guidelines"
        title="Submission Guidelines"
        subtitle="Follow these steps to submit your research paper"
      />

      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <div className="max-w-5xl mx-auto space-y-12">
            {/* Important Dates */}
            <Card className="border-border shadow-card overflow-hidden">
              <div className="gradient-hero p-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-lg bg-accent flex items-center justify-center">
                    <Calendar className="w-6 h-6 text-accent-foreground" />
                  </div>
                  <h2 className="font-display text-2xl font-bold text-primary-foreground">
                    Important Dates
                  </h2>
                </div>
              </div>
              <CardContent className="p-0">
                <div className="divide-y divide-border">
                  {dates.map((item, index) => (
                    <div key={index} className="flex justify-between items-center p-4 hover:bg-muted/50 transition-colors">
                      <span className="text-foreground font-medium">{item.event}</span>
                      <span className="text-accent font-bold font-display">{item.date}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Submission Process */}
            <div>
              <h2 className="font-display text-2xl font-bold text-foreground mb-6 text-center">
                Paper Submission Process
              </h2>
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {steps.map((step, index) => (
                  <Card key={index} className="border-border relative group hover:border-accent/50 transition-colors">
                    <CardContent className="p-6">
                      <div className="absolute top-4 right-4 w-8 h-8 rounded-full bg-accent/10 flex items-center justify-center">
                        <span className="text-accent font-bold text-sm">{index + 1}</span>
                      </div>
                      <div className="w-12 h-12 rounded-lg gradient-hero flex items-center justify-center text-primary-foreground mb-4 group-hover:scale-110 transition-transform">
                        {step.icon}
                      </div>
                      <h3 className="font-display text-lg font-semibold text-foreground mb-2">
                        {step.title}
                      </h3>
                      <p className="text-sm text-muted-foreground">
                        {step.description}
                      </p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            {/* CTA */}
            <div className="text-center">
              <Button variant="hero" size="lg" asChild>
                <Link to="/registration" className="inline-flex items-center gap-2">
                  Proceed to Registration
                  <ArrowRight className="w-4 h-4" />
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </PageLayout>
  );
};

export default Submission;
