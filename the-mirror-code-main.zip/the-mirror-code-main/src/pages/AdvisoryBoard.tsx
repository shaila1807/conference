import PageLayout from "@/components/layout/PageLayout";
import PageHeader from "@/components/common/PageHeader";
import { Card, CardContent } from "@/components/ui/card";

const advisoryBoard = [
  { name: "Prof. (Dr.) Manikarao Salunkhe", position: "Ex. Vice-Chancellor, Central University of Rajasthan, Shivaji University Kolhapur, YCMOU Nashik and Bharti Vidyapeeth Pune" },
  { name: "Prof. (Dr.) Rajanish Kamat", position: "Honorable Vice-Chancellor, Dr. Homi Bhabha State University, HBSU Mumbai" },
  { name: "Prof. (Dr.) S. S. Garje", position: "Dean of Science, University of Mumbai, Maharashtra" },
  { name: "Prof. Dharmendra Makwani", position: "ICFAI Business School, Hyderabad University" },
  { name: "Prof. Shiv Datt Kumar", position: "Professor, Department of Mathematics, MNNIT Allahabad (Prayagraj), U.P." },
  { name: "Dr. Susan Eapen", position: "Adjunct Professor, Bioscience Department UC College, Aluva, Kerala" },
  { name: "S. N. Shetty", position: "Former Principal, K.L.E. Society's Science and Commerce College, Kalamboli" },
  { name: "Prof. Selby Jose", position: "Head, Department of Science, The Institute of Science, Dr. Homi Bhabha State University, Mumbai" },
  { name: "Prof. (Dr.) Rajendra Satpute", position: "Director, ISC, Sambhajinagar" },
  { name: "Prof. (Dr.) P. C. Pandey", position: "Department of Chemistry, Indian Institute of Technology (BHU), Varanasi" },
  { name: "Prof. (Dr.) Vinay Raole", position: "Department of Botany, M.S University Baroda" },
  { name: "Dr. Satish M. P.", position: "Department of Chemistry, K.L.E. Society's Raja Lakhamagouda Science Institute (Autonomous), Belagavi, Karnataka" },
  { name: "Dr. H. M. Meshram", position: "Ex-Chief Scientist (IICT) Hyderabad, Telangana, Director of Mesharam Chemtech PVT. Ltd" },
  { name: "Dr. Diksha Makwani", position: "Sr. Executive Officer, Dept. of Electrical Engineering, IIT Bombay, Powai, Mumbai" },
  { name: "Dr. Partha Sarathi Mandal", position: "Associate Professor, Mathematics and Computing Technology, NIT Patna (Bihar)" },
  { name: "Dr. Usha Karunakaran", position: "Former Associate Professor, Department of Zoology, K.L.E. Society's Science and Commerce College, Kalamboli Navi Mumbai" },
  { name: "Dr. Minakshi Gurav", position: "Associate Professor, Department of Zoology, MES's D.G. Ruparel College of Arts, Science and Commerce, Mumbai" },
  { name: "Dr. Bala Murali S", position: "Assistant Professor at Dwaraka Doss Goverdhan Doss Vaishnav College, Chennai, Tamil Nadu" },
  { name: "Prof. (Dr.) Yogesh Sudhakar Joshi", position: "Professor & Vice Principal, Department of Physics and Electronics, Lal Bahadur Shastri Mahavidyalaya, Dharmabad, Nanded, Maharashtra" },
  { name: "Dr. Akilandeshwari Lakshminarayanan", position: "Associate Professor, Department of Chemistry, Sri Sarada College for Women, Salem, Tamil Nadu" },
  { name: "Dr. Arockiam L.", position: "Associate Professor at St. Joseph's College (Autonomous), Bharathidasan University, Tiruchirappalli, Tamil Nadu" },
  { name: "Prof. (Dr.) Nandkishor S. Chandan", position: "Head, Department of Chemistry, Member, Board of Studies, University of Mumbai, Siddharth College of Arts, Science and Commerce, Mumbai" },
];

const AdvisoryBoard = () => {
  return (
    <PageLayout>
      <PageHeader
        badge="Our Experts"
        title="National Advisory Board"
        subtitle="Distinguished academicians guiding our conference"
      />

      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {advisoryBoard.map((member, index) => (
              <Card key={index} className="border-border hover:border-accent/50 hover:shadow-card transition-all duration-300">
                <CardContent className="p-5">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-full gradient-hero flex items-center justify-center shrink-0">
                      <span className="font-display font-bold text-primary-foreground">
                        {member.name.split(' ').filter(n => !n.includes('.')).map(n => n[0]).join('').slice(0, 2)}
                      </span>
                    </div>
                    <div className="min-w-0">
                      <h3 className="font-display font-semibold text-foreground text-sm leading-tight mb-1">
                        {member.name}
                      </h3>
                      <p className="text-xs text-muted-foreground leading-relaxed">
                        {member.position}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
    </PageLayout>
  );
};

export default AdvisoryBoard;
