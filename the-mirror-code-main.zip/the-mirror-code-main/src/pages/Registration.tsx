import PageLayout from "@/components/layout/PageLayout";
import PageHeader from "@/components/common/PageHeader";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CreditCard, Building, AlertCircle, ExternalLink } from "lucide-react";

const fees = [
  { type: "Research Scholars & Students", fee: "Rs. 1,500/-", note: "per paper presenter" },
  { type: "Industry Delegate", fee: "Rs. 2,000/-", note: "" },
  { type: "Only Attendee (Participation)", fee: "Rs. 1,000/-", note: "" },
  { type: "In-House Students", fee: "Rs. 750/-", note: "" },
];

const Registration = () => {
  return (
    <PageLayout>
      <PageHeader
        badge="Join Us"
        title="Registration"
        subtitle="Register for SciFusion 1.0 - National Conference 2026"
      />

      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto space-y-8">
            {/* Registration Fees */}
            <Card className="border-border shadow-card">
              <CardHeader>
                <CardTitle className="font-display text-2xl flex items-center gap-3">
                  <CreditCard className="w-6 h-6 text-accent" />
                  Registration Fees
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-border">
                        <th className="text-left py-3 px-4 font-display font-semibold text-foreground">
                          Delegate Type
                        </th>
                        <th className="text-right py-3 px-4 font-display font-semibold text-foreground">
                          Registration Fee
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {fees.map((item, index) => (
                        <tr key={index} className="border-b border-border/50 hover:bg-muted/50 transition-colors">
                          <td className="py-4 px-4">
                            <span className="font-medium text-foreground">{item.type}</span>
                            {item.note && (
                              <span className="text-sm text-muted-foreground ml-2">({item.note})</span>
                            )}
                          </td>
                          <td className="py-4 px-4 text-right">
                            <span className="font-display font-bold text-accent text-lg">{item.fee}</span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>

            {/* Payment Details */}
            <Card className="border-border shadow-card">
              <CardHeader>
                <CardTitle className="font-display text-2xl flex items-center gap-3">
                  <Building className="w-6 h-6 text-accent" />
                  Payment Details
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="bg-muted rounded-lg p-6">
                  <h4 className="font-semibold text-foreground mb-4">Bank Transfer Details</h4>
                  <div className="grid sm:grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-muted-foreground">Account Name:</span>
                      <p className="font-medium text-foreground">Principal K.L.E. Society's Science and Commerce College</p>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Account Number:</span>
                      <p className="font-medium text-foreground font-mono">913010032164305</p>
                    </div>
                    <div>
                      <span className="text-muted-foreground">IFSC Code:</span>
                      <p className="font-medium text-foreground font-mono">UTIB0001965</p>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Bank Name:</span>
                      <p className="font-medium text-foreground">Axis Bank Ltd., Kalamboli, Navi Mumbai</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Important Note */}
            <Card className="border-accent/30 bg-accent/5">
              <CardContent className="p-6">
                <div className="flex gap-4">
                  <AlertCircle className="w-6 h-6 text-accent shrink-0 mt-0.5" />
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Important Note</h4>
                    <p className="text-muted-foreground text-sm">
                      Registration will be per Paper and for participating in offline conferences, 
                      other co-authors need to pay participation charges. Please attach a screenshot 
                      of payment in the registration form.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* CTA */}
            <div className="text-center pt-4">
              <p className="text-muted-foreground mb-4">
                Ready to register? Click the button below to access the registration form.
              </p>
              <Button variant="hero" size="xl" className="animate-pulse-glow">
                <span className="flex items-center gap-2">
                  Register Now
                  <ExternalLink className="w-5 h-5" />
                </span>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </PageLayout>
  );
};

export default Registration;
