import PageLayout from "@/components/layout/PageLayout";
import PageHeader from "@/components/common/PageHeader";
import { Card, CardContent } from "@/components/ui/card";
import { GraduationCap, Award, Calendar, Building } from "lucide-react";

const stats = [
  { icon: <Calendar className="w-6 h-6" />, value: "2013", label: "Established" },
  { icon: <Building className="w-6 h-6" />, value: "Kalamboli", label: "Location" },
  { icon: <Award className="w-6 h-6" />, value: "B+", label: "NAAC Grade" },
  { icon: <GraduationCap className="w-6 h-6" />, value: "Mumbai", label: "University Affiliated" },
];

const AboutCollege = () => {
  return (
    <PageLayout>
      <PageHeader
        badge="About Us"
        title="Our College"
        subtitle="K.L.E. Society's Science and Commerce College, Kalamboli"
      />

      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-12">
            {stats.map((stat, index) => (
              <Card key={index} className="border-border text-center">
                <CardContent className="p-6">
                  <div className="w-12 h-12 rounded-lg gradient-hero flex items-center justify-center text-primary-foreground mx-auto mb-3">
                    {stat.icon}
                  </div>
                  <p className="font-display text-2xl font-bold text-accent">{stat.value}</p>
                  <p className="text-sm text-muted-foreground">{stat.label}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Content */}
          <div className="max-w-4xl mx-auto">
            <Card className="border-border shadow-card">
              <CardContent className="p-8 md:p-12">
                <h2 className="font-display text-2xl font-bold text-foreground mb-6">
                  A Proud Branch of KLE Society
                </h2>
                <div className="prose prose-lg max-w-none text-muted-foreground space-y-6">
                  <p className="leading-relaxed">
                    KLE Society's Science and Commerce College, Kalamboli is one of the proud 
                    branches of KLE Society. KLE College, a minority Higher Educational Institution, 
                    located at Kalamboli, Navi Mumbai made its prosperous beginning in the year 
                    <span className="text-accent font-semibold"> 2013</span> and has evolved over the years.
                  </p>
                  
                  <p className="leading-relaxed">
                    The College has been affiliated to the <span className="font-semibold text-foreground">University of Mumbai</span> since 
                    the time of its inception in 2013. We at KLE are committed to offering quality 
                    learning experience in diverse educational programmes.
                  </p>

                  <div className="bg-accent/10 border-l-4 border-accent rounded-r-lg p-6 my-8">
                    <p className="text-foreground font-semibold text-lg mb-2">
                      NAAC Accredited B+ Grade
                    </p>
                    <p className="text-muted-foreground">
                      Our college is accredited with B+ grade in NAAC (First Cycle), 
                      reflecting our commitment to academic excellence and quality education.
                    </p>
                  </div>

                  <div className="mt-8">
                    <h3 className="font-display text-xl font-semibold text-foreground mb-3">
                      Location
                    </h3>
                    <p className="leading-relaxed">
                      Plot No. 29, Sector-01, Kalamboli<br />
                      Navi Mumbai – 410218<br />
                      Maharashtra, India
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </PageLayout>
  );
};

export default AboutCollege;
