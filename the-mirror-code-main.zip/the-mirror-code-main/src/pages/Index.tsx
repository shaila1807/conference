import PageLayout from "@/components/layout/PageLayout";
import HeroSection from "@/components/home/HeroSection";
import HighlightsSection from "@/components/home/HighlightsSection";
import ImportantDatesSection from "@/components/home/ImportantDatesSection";
import ThemesPreviewSection from "@/components/home/ThemesPreviewSection";
import SpeakersPreviewSection from "@/components/home/SpeakersPreviewSection";
import CTASection from "@/components/home/CTASection";

const Index = () => {
  return (
    <PageLayout>
      <HeroSection />
      <HighlightsSection />
      <ImportantDatesSection />
      <ThemesPreviewSection />
      <SpeakersPreviewSection />
      <CTASection />
    </PageLayout>
  );
};

export default Index;
