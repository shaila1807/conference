import PageLayout from "@/components/layout/PageLayout";
import PageHeader from "@/components/common/PageHeader";
import { Card, CardContent } from "@/components/ui/card";
import drPrabhakarKore from "@/assets/dr-prabhakar-kore.png";
import shriMahanteshKavatagimath from "@/assets/shri-mahantesh-kavatagimath.jpeg";

const patrons = [
  {
    name: "Dr. Prabhakar B. Kore",
    title: "Hon. Chairman, KLE Society & Chancellor, KLE University, Belgaum",
    image: drPrabhakarKore,
    description: `A legendary figure in the domain of education, health care, co-operative endeavor and community building. A second time MP in the Rajya Sabha, Dr. P. B. Kore is well known in the political and social circles for his significant contributions and commitment to the transformation of society through education and healthcare.

He is a progressive leader whose missionary zeal and firm commitment have pioneered the march of KLE in Health Science, education and research. He has received the recent Life Time Achievement Award by the prestigious Indo American Press Club USA in May 2022 in New York. He is the first Indian to receive this honour.`,
  },
  {
    name: "Shri. Mahantesh Mallikarjun Kavatagimath",
    title: "Governing Body Chairman, KLE Society's Science and Commerce College, Kalamboli",
    image: shriMahanteshKavatagimath,
    description: `A distinguished public leader and former Chief Whip of the BJP in the Karnataka Legislative Council. He was twice elected from the Belgaum Local Authorities Constituency.

As Governing Body Chairman, he provides visionary leadership and strong support for academic excellence and institutional development.`,
  },
];

const Patron = () => {
  return (
    <PageLayout>
      <PageHeader
        badge="Leadership"
        title="Conference Patrons"
        subtitle="Visionary leaders guiding our mission of academic excellence"
      />

      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto space-y-8">
            {patrons.map((patron, index) => (
              <Card key={index} className="border-border shadow-card overflow-hidden">
                <CardContent className="p-0">
                  <div className="md:flex">
                    {/* Avatar section */}
                    <div className="md:w-1/3 gradient-hero p-8 flex items-center justify-center">
                      <div className="w-32 h-32 rounded-full border-4 border-accent overflow-hidden">
                        <img 
                          src={patron.image} 
                          alt={patron.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                    </div>
                    
                    {/* Content section */}
                    <div className="md:w-2/3 p-8">
                      <h2 className="font-display text-2xl font-bold text-foreground mb-2">
                        {patron.name}
                      </h2>
                      <p className="text-accent font-medium mb-4">
                        {patron.title}
                      </p>
                      <div className="text-muted-foreground space-y-4">
                        {patron.description.split('\n\n').map((paragraph, idx) => (
                          <p key={idx} className="leading-relaxed">
                            {paragraph}
                          </p>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
    </PageLayout>
  );
};

export default Patron;
