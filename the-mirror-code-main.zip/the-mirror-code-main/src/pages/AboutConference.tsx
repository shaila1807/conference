import PageLayout from "@/components/layout/PageLayout";
import PageHeader from "@/components/common/PageHeader";
import { Card, CardContent } from "@/components/ui/card";
import { Target, Users, Lightbulb, BookOpen } from "lucide-react";

const AboutConference = () => {
  return (
    <PageLayout>
      <PageHeader
        badge="SciFusion 1.0"
        title="About the Conference"
        subtitle="Two Days National Conference on Interdisciplinary Scientific Research"
      />

      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto space-y-12">
            {/* Main description */}
            <Card className="border-border shadow-card">
              <CardContent className="p-8 md:p-12">
                <h2 className="font-display text-2xl font-bold text-foreground mb-6">
                  Conference Overview
                </h2>
                <div className="prose prose-lg max-w-none text-muted-foreground space-y-6">
                  <p className="leading-relaxed">
                    The conference is organized by the <span className="font-semibold text-foreground">Science Department / Science Section</span> in 
                    collaboration with the <span className="font-semibold text-foreground">Internal Quality Assurance Cell (IQAC)</span>.
                  </p>
                  
                  <p className="leading-relaxed">
                    It aims to address contemporary transformations and emerging trends across the 
                    global scientific landscape in the disciplines of <span className="text-accent">Chemistry, Mathematics, 
                    Information Technology, Hospitality Studies, Physics, Botany, and Zoology</span>.
                  </p>

                  <p className="leading-relaxed">
                    The conference provides an interdisciplinary academic platform for distinguished 
                    academicians, industry professionals, technical experts, and research scholars to 
                    present, exchange, and critically discuss their research outcomes, innovations, 
                    and scholarly contributions.
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Objective */}
            <Card className="border-border shadow-card overflow-hidden">
              <div className="gradient-hero p-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-lg bg-accent flex items-center justify-center">
                    <Target className="w-6 h-6 text-accent-foreground" />
                  </div>
                  <h2 className="font-display text-2xl font-bold text-primary-foreground">
                    Conference Objective
                  </h2>
                </div>
              </div>
              <CardContent className="p-8">
                <p className="text-lg text-muted-foreground leading-relaxed">
                  To critically assess ongoing advancements and anticipate future challenges in 
                  science and technology through interdisciplinary research and discussion.
                </p>
              </CardContent>
            </Card>

            {/* Key features */}
            <div className="grid md:grid-cols-3 gap-6">
              <Card className="border-border text-center">
                <CardContent className="p-6">
                  <div className="w-14 h-14 rounded-lg gradient-hero flex items-center justify-center text-primary-foreground mx-auto mb-4">
                    <Users className="w-7 h-7" />
                  </div>
                  <h3 className="font-display text-lg font-semibold text-foreground mb-2">
                    For Researchers
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    Present your research to a national audience of scholars and experts
                  </p>
                </CardContent>
              </Card>

              <Card className="border-border text-center">
                <CardContent className="p-6">
                  <div className="w-14 h-14 rounded-lg gradient-hero flex items-center justify-center text-primary-foreground mx-auto mb-4">
                    <Lightbulb className="w-7 h-7" />
                  </div>
                  <h3 className="font-display text-lg font-semibold text-foreground mb-2">
                    Innovation Hub
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    Exchange ideas and discover new approaches to scientific challenges
                  </p>
                </CardContent>
              </Card>

              <Card className="border-border text-center">
                <CardContent className="p-6">
                  <div className="w-14 h-14 rounded-lg gradient-hero flex items-center justify-center text-primary-foreground mx-auto mb-4">
                    <BookOpen className="w-7 h-7" />
                  </div>
                  <h3 className="font-display text-lg font-semibold text-foreground mb-2">
                    Publication
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    Selected papers published in Scopus-indexed journal
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>
    </PageLayout>
  );
};

export default AboutConference;
