import PageLayout from "@/components/layout/PageLayout";
import PageHeader from "@/components/common/PageHeader";
import { Card, CardContent } from "@/components/ui/card";
import { Phone, Mail, MapPin, ExternalLink, User } from "lucide-react";

const Contact = () => {
  return (
    <PageLayout>
      <PageHeader
        badge="Get In Touch"
        title="Contact Us"
        subtitle="Have questions? We're here to help"
      />

      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <div className="max-w-5xl mx-auto">
            <div className="grid md:grid-cols-2 gap-8">
              {/* Contact Info */}
              <div className="space-y-6">
                <Card className="border-border shadow-card">
                  <CardContent className="p-6">
                    <h3 className="font-display text-xl font-bold text-foreground mb-4">
                      Conference Contact
                    </h3>
                    <div className="space-y-4">
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 rounded-lg gradient-hero flex items-center justify-center text-primary-foreground shrink-0">
                          <User className="w-5 h-5" />
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Contact Person</p>
                          <p className="font-medium text-foreground">Asst. Prof. Madhavi Joshi</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 rounded-lg gradient-hero flex items-center justify-center text-primary-foreground shrink-0">
                          <Phone className="w-5 h-5" />
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Phone</p>
                          <a href="tel:7718960509" className="font-medium text-accent hover:underline">
                            7718960509
                          </a>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-border shadow-card">
                  <CardContent className="p-6">
                    <h3 className="font-display text-xl font-bold text-foreground mb-4">
                      College Contact
                    </h3>
                    <div className="space-y-4">
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 rounded-lg gradient-hero flex items-center justify-center text-primary-foreground shrink-0">
                          <Phone className="w-5 h-5" />
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Phone</p>
                          <a href="tel:022-27423300" className="font-medium text-accent hover:underline">
                            022-27423300
                          </a>
                        </div>
                      </div>
                      <div className="flex items-start gap-4">
                        <div className="w-10 h-10 rounded-lg gradient-hero flex items-center justify-center text-primary-foreground shrink-0">
                          <Mail className="w-5 h-5" />
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Email</p>
                          <a href="mailto:scienceconference@klessccmumbai.edu.in" className="font-medium text-accent hover:underline break-all">
                            scienceconference@klessccmumbai.edu.in
                          </a>
                        </div>
                      </div>
                      <div className="flex items-start gap-4">
                        <div className="w-10 h-10 rounded-lg gradient-hero flex items-center justify-center text-primary-foreground shrink-0">
                          <ExternalLink className="w-5 h-5" />
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Website</p>
                          <a href="https://klessccmumbai.edu.in" target="_blank" rel="noopener noreferrer" className="font-medium text-accent hover:underline">
                            klessccmumbai.edu.in
                          </a>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Venue */}
              <Card className="border-border shadow-card h-fit">
                <CardContent className="p-6">
                  <h3 className="font-display text-xl font-bold text-foreground mb-4 flex items-center gap-2">
                    <MapPin className="w-5 h-5 text-accent" />
                    Conference Venue
                  </h3>
                  <div className="space-y-4">
                    <div className="bg-muted rounded-lg p-4">
                      <p className="font-semibold text-foreground mb-2">K.L.E. Society's</p>
                      <p className="text-foreground">Science and Commerce College</p>
                      <p className="text-muted-foreground mt-2">
                        Plot No. 29, Sector-01<br />
                        Kalamboli, Navi Mumbai – 410218<br />
                        Maharashtra, India
                      </p>
                    </div>

                    {/* Map embed placeholder */}
                    <div className="aspect-video bg-muted rounded-lg overflow-hidden">
                      <iframe
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3773.123456!2d73.123456!3d19.123456!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMTnCsDA3JzMwLjQiTiA3M8KwMDcnMjQuNCJF!5e0!3m2!1sen!2sin!4v1234567890"
                        width="100%"
                        height="100%"
                        style={{ border: 0 }}
                        allowFullScreen
                        loading="lazy"
                        referrerPolicy="no-referrer-when-downgrade"
                        title="Conference Venue Map"
                      />
                    </div>

                    <a
                      href="https://share.google/N30BNEletCd5lUCLj"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 text-accent hover:underline font-medium"
                    >
                      View on Google Maps
                      <ExternalLink className="w-4 h-4" />
                    </a>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>
    </PageLayout>
  );
};

export default Contact;
