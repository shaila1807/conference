import PageLayout from "@/components/layout/PageLayout";
import PageHeader from "@/components/common/PageHeader";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { FlaskConical, Calculator, Cpu, Atom, Leaf, Bug, UtensilsCrossed } from "lucide-react";

const themes = [
  {
    icon: <FlaskConical className="w-8 h-8" />,
    name: "Chemistry",
    color: "from-orange-500 to-red-500",
    topics: [
      "Environmental Chemistry",
      "Analytical Chemistry",
      "Green Chemistry",
      "Medicinal Chemistry",
      "Computational Chemistry",
      "Cheminformatics",
      "Softwares in Chemistry",
      "Drug Designing",
      "Applied Chemistry",
      "Metallurgy",
      "Engineering Chemistry",
      "Bioinorganic Chemistry",
      "Organometallics and Catalysis",
    ],
  },
  {
    icon: <Calculator className="w-8 h-8" />,
    name: "Mathematics",
    color: "from-blue-500 to-indigo-500",
    sections: [
      {
        title: "Pure Mathematics",
        topics: ["Algebra", "Linear Algebra", "Mathematical Analysis", "Mathematical Logic & Foundations", "Functional Analysis", "Topology"],
      },
      {
        title: "Applied Mathematics",
        topics: ["Operations Research", "Differential Equations", "Integral Transforms", "Fluid Mechanics", "Graph Theory", "Number Theory", "Coding Theory"],
      },
      {
        title: "Data Science",
        topics: ["Machine Learning", "Optimization Techniques", "Mathematics of Deep Learning and Neural Networks", "Time Series Analysis and Forecasting Models", "Bayesian Mathematics for Decision-Making Systems"],
      },
      {
        title: "Computational Mathematics",
        topics: ["Computational Statistics and Probability Theory", "Numerical Analysis and Scientific Computing", "Industrial Mathematics", "Mathematical Finance", "Mathematical Modeling and Simulations"],
      },
    ],
  },
  {
    icon: <Cpu className="w-8 h-8" />,
    name: "Information Technology",
    color: "from-cyan-500 to-blue-500",
    topics: [
      "Machine Learning",
      "Data Science",
      "Robotics",
      "Innovation in AI",
      "Big Data Analytics",
      "Blockchain Technology",
      "Cloud Computing",
      "Internet of Things",
      "Cyber Security",
    ],
  },
  {
    icon: <Atom className="w-8 h-8" />,
    name: "Physics",
    color: "from-purple-500 to-pink-500",
    topics: [
      "Dielectrics and Spectroscopic Techniques in Modern Physics",
      "Thin Films, Coatings, and Sensor Technologies",
      "Quantum Physics and Quantum Technologies",
      "Computational Physics and Materials Science",
      "Advanced Functional Materials",
      "Nanotechnology and Nanomaterials for Emerging Applications",
      "Photonics, Optoelectronics, and Laser Physics",
      "Applied Physics and Industrial Applications",
      "Modeling of Physical Systems",
      "Societal and Technological Applications",
    ],
  },
  {
    icon: <Leaf className="w-8 h-8" />,
    name: "Botany",
    color: "from-green-500 to-emerald-500",
    topics: [
      "Plant–Microbe Interactions for Sustainable Agriculture (Rhizosphere biology, biofertilizers, PGPR, mycorrhizae)",
      "Phytochemicals and Secondary Metabolites in Drug Discovery (Alkaloids, steroids, flavonoids, green extraction approaches)",
      "Plant-Based Nanotechnology / Green Synthesis of Nanoparticles (Metal nanoparticles using plant extracts, biomedical and environmental applications)",
      "Climate Change Impact on Plant Physiology and Phenology (Stress tolerance, drought/salinity responses, shifting flowering patterns)",
      "Algal Biotechnology and Its Applications (Biofuels, wastewater treatment, carbon sequestration, nutraceuticals)",
    ],
  },
  {
    icon: <Bug className="w-8 h-8" />,
    name: "Zoology",
    color: "from-amber-500 to-orange-500",
    topics: [
      "Animal Physiology and Behavior",
      "Human-Animal Health",
      "Genetics and Evolution",
      "Ecology and Environmental Zoology",
      "Biodiversity and Conservation",
      "Zoology in a Changing World",
      "Advances in Zoological Research for a Sustainable Future",
      "One Health: Connecting Species and Planetary Health",
    ],
  },
  {
    icon: <UtensilsCrossed className="w-8 h-8" />,
    name: "Hospitality Studies",
    color: "from-rose-500 to-red-500",
    topics: [
      "Next-Generation Innovations in the Hospitality & Tourism Industry",
      "Digital Influence & Street Food: Opportunities for Small Vendors",
      "Balancing Tourism Expansion and Environmental Sustainability: A National Perspective",
      "Smart Hospitality: Finding the Perfect Blend of Automation and Personalisation for the Next Generation",
      "Preserving Roots, Inspiring Change: The Evolution of Traditional Cuisine for Gen Next",
      "Emotional Intelligence in the Front Office: Managing Stress and Delivering Excellence",
    ],
  },
];

const Themes = () => {
  return (
    <PageLayout>
      <PageHeader
        badge="Call For Papers"
        title="Research Themes"
        subtitle="Submit your research in any of these interdisciplinary scientific domains"
      />

      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <div className="space-y-8">
            {themes.map((theme, index) => (
              <Card key={index} className="border-border shadow-card overflow-hidden">
                <CardHeader className={`bg-gradient-to-r ${theme.color} text-white`}>
                  <div className="flex items-center gap-4">
                    <div className="w-14 h-14 rounded-lg bg-white/20 flex items-center justify-center">
                      {theme.icon}
                    </div>
                    <CardTitle className="font-display text-2xl">{theme.name}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent className="p-6">
                  {theme.sections ? (
                    <div className="grid md:grid-cols-2 gap-6">
                      {theme.sections.map((section, sIdx) => (
                        <div key={sIdx}>
                          <h4 className="font-display font-semibold text-foreground mb-3">
                            {section.title}
                          </h4>
                          <ul className="space-y-2">
                            {section.topics.map((topic, tIdx) => (
                              <li key={tIdx} className="flex items-start gap-2 text-muted-foreground">
                                <span className="w-1.5 h-1.5 rounded-full bg-accent mt-2 shrink-0" />
                                <span>{topic}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <ul className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
                      {theme.topics?.map((topic, tIdx) => (
                        <li key={tIdx} className="flex items-start gap-2 text-muted-foreground">
                          <span className="w-1.5 h-1.5 rounded-full bg-accent mt-2 shrink-0" />
                          <span>{topic}</span>
                        </li>
                      ))}
                    </ul>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
    </PageLayout>
  );
};

export default Themes;
