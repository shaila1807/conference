import PageLayout from "@/components/layout/PageLayout";
import PageHeader from "@/components/common/PageHeader";
import { Card, CardContent } from "@/components/ui/card";
import { Clock, Coffee, Users, Mic, BookOpen, Sprout } from "lucide-react";

const day1Schedule = [
  { time: "09:00 AM", event: "Registration & Welcome Kit Distribution", icon: <Users className="w-5 h-5" /> },
  { time: "10:00 AM", event: "Inauguration Ceremony", icon: <Mic className="w-5 h-5" /> },
  { time: "11:00 AM", event: "Keynote Address - Prof. (Dr.) B. M. Bhanage", icon: <Mic className="w-5 h-5" /> },
  { time: "12:00 PM", event: "Tea Break & Networking", icon: <Coffee className="w-5 h-5" /> },
  { time: "12:30 PM", event: "Paper Presentation Session I", icon: <BookOpen className="w-5 h-5" /> },
  { time: "02:00 PM", event: "Lunch Break", icon: <Coffee className="w-5 h-5" /> },
  { time: "03:00 PM", event: "Keynote Address - Dr. Achyut Godbole", icon: <Mic className="w-5 h-5" /> },
  { time: "04:00 PM", event: "Paper Presentation Session II", icon: <BookOpen className="w-5 h-5" /> },
  { time: "05:30 PM", event: "End of Day 1", icon: <Clock className="w-5 h-5" /> },
];

const day2Schedule = [
  { time: "09:30 AM", event: "Keynote Address - Prof. A.V. Mahajan", icon: <Mic className="w-5 h-5" /> },
  { time: "10:30 AM", event: "Paper Presentation Session III", icon: <BookOpen className="w-5 h-5" /> },
  { time: "12:00 PM", event: "Tea Break", icon: <Coffee className="w-5 h-5" /> },
  { time: "12:30 PM", event: "Lab to Land: Scientists-Farmers Discussion", icon: <Sprout className="w-5 h-5" /> },
  { time: "02:00 PM", event: "Lunch Break", icon: <Coffee className="w-5 h-5" /> },
  { time: "03:00 PM", event: "Keynote Address - Dr. Anupam Dhoundiyal", icon: <Mic className="w-5 h-5" /> },
  { time: "04:00 PM", event: "Paper Presentation Session IV", icon: <BookOpen className="w-5 h-5" /> },
  { time: "05:00 PM", event: "Valedictory Function & Prize Distribution", icon: <Users className="w-5 h-5" /> },
  { time: "06:00 PM", event: "Conference Concludes", icon: <Clock className="w-5 h-5" /> },
];

const Schedule = () => {
  return (
    <PageLayout>
      <PageHeader
        badge="Conference Timeline"
        title="Schedule"
        subtitle="Two days of inspiring sessions, presentations, and networking"
      />

      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="grid md:grid-cols-2 gap-8">
              {/* Day 1 */}
              <div>
                <div className="gradient-hero text-primary-foreground rounded-t-lg p-4 text-center">
                  <h2 className="font-display text-xl font-bold">Day 1</h2>
                  <p className="text-primary-foreground/80 text-sm">13th March 2026</p>
                </div>
                <Card className="rounded-t-none border-t-0">
                  <CardContent className="p-0">
                    <div className="divide-y divide-border">
                      {day1Schedule.map((item, index) => (
                        <div key={index} className="flex items-center gap-4 p-4 hover:bg-muted/50 transition-colors">
                          <div className="w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center text-accent shrink-0">
                            {item.icon}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-foreground font-medium text-sm">{item.event}</p>
                            <p className="text-accent text-xs font-semibold">{item.time}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Day 2 */}
              <div>
                <div className="gradient-gold text-accent-foreground rounded-t-lg p-4 text-center">
                  <h2 className="font-display text-xl font-bold">Day 2</h2>
                  <p className="text-accent-foreground/80 text-sm">14th March 2026</p>
                </div>
                <Card className="rounded-t-none border-t-0">
                  <CardContent className="p-0">
                    <div className="divide-y divide-border">
                      {day2Schedule.map((item, index) => (
                        <div key={index} className="flex items-center gap-4 p-4 hover:bg-muted/50 transition-colors">
                          <div className="w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center text-accent shrink-0">
                            {item.icon}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-foreground font-medium text-sm">{item.event}</p>
                            <p className="text-accent text-xs font-semibold">{item.time}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* Note */}
            <p className="text-center text-muted-foreground text-sm mt-8">
              * Schedule is tentative and subject to minor changes
            </p>
          </div>
        </div>
      </section>
    </PageLayout>
  );
};

export default Schedule;
