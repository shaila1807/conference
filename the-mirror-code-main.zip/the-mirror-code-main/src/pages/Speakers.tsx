import PageLayout from "@/components/layout/PageLayout";
import PageHeader from "@/components/common/PageHeader";
import { Card, CardContent } from "@/components/ui/card";
import dadajiBhuse from "@/assets/dadaji-bhuse.jpg";
import profBmBhanage from "@/assets/prof-bm-bhanage.jpg";
import drAchyutGodbole from "@/assets/dr-achyut-godbole.jpg";
import profAvMahajan from "@/assets/prof-av-mahajan.jpg";
import drAnupamDhoundiyal from "@/assets/dr-anupam-dhoundiyal.png";

const keynoteSpeakers = [
  {
    name: "Prof. (Dr.) B. M. Bhanage",
    title: "Hon. Vice Chancellor",
    institution: "MS University, Baroda",
    image: profBmBhanage,
    description: `Prof. B. M. Bhanage is a distinguished academic leader and internationally reputed researcher in catalysis and green synthesis. A former Professor at Institute of Chemical Technology, Mumbai, he has made significant contributions to sustainable chemical transformations and has been instrumental in advancing academic–industry partnerships.

In recognition of his outstanding scientific achievements, he was awarded the SMC Silver Medal Award 2025 at the SMC AGBM, held at BARC, November 2025. As a Vice Chancellor, he continues to foster excellence, innovation, and inclusivity in higher education through research-driven and socially relevant initiatives.`,
  },
  {
    name: "Dr. Achyut Godbole",
    title: "Scientist, Technologist, Entrepreneur, Mentor, Author",
    institution: "IIT Mumbai Alumni",
    image: drAchyutGodbole,
    description: `Dr. Achyut Godbole is an Indian businessman and writer from Mumbai, India. He served as the CEO of Patni Computer Systems for nearly 23 years and has held leadership positions in several other IT firms during the 1980s and 1990s.

Currently, he is the Managing Director of SoftExcel Services, where he advises global companies on growth strategies and setting up offshore delivery organizations. Additionally, he is an accomplished author with 31 books to his name, covering various topics. Dr. Godbole is also an alumnus of IIT Mumbai, where he excelled academically.`,
  },
  {
    name: "Prof. A.V. Mahajan",
    title: "Professor, Department of Physics",
    institution: "IIT Bombay, Mumbai",
    image: profAvMahajan,
    description: `Prof. Avinash V. Mahajan is a distinguished experimental condensed matter physicist with over two decades of teaching and research experience at premier academic institutions. His expertise lies in low-dimensional quantum magnetic systems and strongly correlated materials.

He has published approximately 90 research papers in reputed international journals, receiving over 2,600 citations with an h-index of about 25. He has successfully supervised several Ph.D. scholars and has made significant contributions to advanced experimental research, quantum magnetism and higher education at IIT Bombay.`,
  },
  {
    name: "Dr. Anupam Dhoundiyal",
    title: "Dean of Hospitality Studies",
    institution: "Training Ship Rahaman Nhava, Raigad",
    image: drAnupamDhoundiyal,
    description: `Former Principal - Jodhpur Institute of Hotel Management. Executive Chef - Kohinoor Continental Hotel Mumbai & Best Western Mumbai. A committed academic and researcher, Dr. Dhoundiyal has published 9 research papers, contributed chapters to two books, and authored one book to date.

Professional educationalist with strong administration and planning skills. Designed and inducted three prestigious hospitality colleges. Qualified Internal Auditor for ISO 9001 quality system.`,
  },
];

const specialInvitee = {
  name: "Hon. Shri. Dadaji Dagdu Bhuse",
  title: "Minister of School Education, Maharashtra",
  image: dadajiBhuse,
  description: `Shri. Dadaji Bhuse is a member of the 16th Maharashtra Legislative Assembly, representing the Malegaon Outer Assembly Constituency, and is currently serving as Maharashtra's Cabinet Minister for Agriculture & Ex-Servicemen Welfare.

Formerly as School Education Minister, he led major reforms including curriculum modernization, emphasis on conceptual learning, and holistic development of students across the state.`,
};

const Speakers = () => {
  return (
    <PageLayout>
      <PageHeader
        badge="Learn From The Best"
        title="Keynote Speakers"
        subtitle="Distinguished scientists, academics, and industry leaders"
      />

      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          {/* Special Invitee */}
          <div className="max-w-4xl mx-auto mb-12">
            <h2 className="font-display text-2xl font-bold text-foreground mb-6 text-center">
              Special Invitee
            </h2>
            <Card className="border-accent/30 shadow-card overflow-hidden">
              <CardContent className="p-0">
                <div className="md:flex">
                  <div className="md:w-1/3 gradient-gold p-6 sm:p-8 flex items-center justify-center">
                    <div className="w-24 h-24 sm:w-32 sm:h-32 rounded-full border-4 border-accent-foreground/30 overflow-hidden">
                      <img 
                        src={specialInvitee.image} 
                        alt={specialInvitee.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  </div>
                  <div className="md:w-2/3 p-6 sm:p-8">
                    <h3 className="font-display text-xl sm:text-2xl font-bold text-foreground mb-2">
                      {specialInvitee.name}
                    </h3>
                    <p className="text-accent font-medium mb-4">{specialInvitee.title}</p>
                    <div className="text-muted-foreground space-y-4">
                      {specialInvitee.description.split('\n\n').map((p, i) => (
                        <p key={i} className="leading-relaxed">{p}</p>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Keynote Speakers */}
          <div className="max-w-4xl mx-auto">
            <h2 className="font-display text-2xl font-bold text-foreground mb-6 text-center">
              Keynote Speakers
            </h2>
            <div className="space-y-8">
              {keynoteSpeakers.map((speaker, index) => (
                <Card key={index} className="border-border shadow-card overflow-hidden">
                  <CardContent className="p-0">
                    <div className="md:flex">
                      <div className="md:w-1/3 gradient-hero p-6 sm:p-8 flex items-center justify-center">
                        <div className="w-24 h-24 sm:w-32 sm:h-32 rounded-full border-4 border-accent overflow-hidden">
                          <img 
                            src={speaker.image} 
                            alt={speaker.name}
                            className="w-full h-full object-cover"
                          />
                        </div>
                      </div>
                      <div className="md:w-2/3 p-6 sm:p-8">
                        <h3 className="font-display text-lg sm:text-xl font-bold text-foreground mb-1">
                          {speaker.name}
                        </h3>
                        <p className="text-accent font-medium mb-1">{speaker.title}</p>
                        <p className="text-muted-foreground text-sm mb-4">{speaker.institution}</p>
                        <div className="text-muted-foreground text-sm space-y-3">
                          {speaker.description.split('\n\n').map((p, i) => (
                            <p key={i} className="leading-relaxed">{p}</p>
                          ))}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>
    </PageLayout>
  );
};

export default Speakers;
